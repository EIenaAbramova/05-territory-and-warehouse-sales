from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from shutil import copy2
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
PUBLISH=ROOT.parent/'GitHub/05-territory-and-warehouse-sales'
PUBLISH.mkdir(parents=True,exist_ok=True)
archive=PUBLISH/'05-complete.zip'
paths=[ROOT/'README.md',ROOT/'requirements.txt',ROOT/'package.json']
for folder in ['src','docs','sql']:
 paths.extend(p for p in (ROOT/folder).glob('*') if p.is_file())
paths.extend(p for p in (ROOT/'output').glob('*') if p.suffix in ('.xlsx','.json'))
with ZipFile(archive,'w',ZIP_DEFLATED) as z:
 for p in paths:z.write(p,p.relative_to(ROOT).as_posix())
 z.write(ROOT.parent/'Тестирование_корпоративная_аналитика.xlsx','input/Тестирование_корпоративная_аналитика.xlsx')
 z.write(ROOT.parent/'ТЗ.docx','input/ТЗ.docx')
 z.write(ROOT/'qa/behavior.json','qa/behavior.json')
with ZipFile(archive) as z:assert z.testzip() is None
for p in [ROOT/'output/05_решение.xlsx',ROOT/'sql/solution.sql',ROOT/'docs/Конспект.md',ROOT/'docs/Аналитическая записка.md',ROOT/'docs/Задание.md',ROOT/'docs/monthly_series.json',ROOT/'output/summary.json',ROOT/'output/verification.json',ROOT/'output/sql_verification.json']:
 copy2(p,PUBLISH/p.name)
readme=(ROOT/'README.md').read_text(encoding='utf8')
for prefix in ['output/','sql/','docs/']:readme=readme.replace(']('+prefix,'](')
start=readme.index('Скрипты в src позволяют')
end=readme.index('\n## Проверка',start)
readme=readme[:start]+'''[Скачать полный проект с исходниками и данными](05-complete.zip). Архив содержит папки src, docs, sql, input и output, зависимости и инструкции по пересборке. Описанные в конспекте пути относятся к структуре внутри архива.
'''+readme[end:]
(PUBLISH/'README.md').write_text(readme,encoding='utf8')
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in PUBLISH.iterdir() if p.is_file()}
(ROOT/'qa/publication_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'publication_folder':str(PUBLISH),'files':list(manifest),'archive_bytes':archive.stat().st_size},ensure_ascii=False,indent=2))
