import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const d=JSON.parse(await fs.readFile(path.join(root,'qa/data.json'),'utf8'));
const wb=Workbook.create();
const names=['Итоги','Недели и территории','Динамика','Месячные показатели','Данные','Лист1','Лист2','Проверки','Сводная'];
const sheets=Object.fromEntries(names.map(n=>[n,wb.worksheets.add(n)]));
function put(s,cell,v){s.getRange(cell).write(v);}
function f(s,cell,v){s.getRange(cell).formulas=v;}
function title(s,text,last='H'){s.mergeCells(`A2:${last}2`);put(s,'A2',[[text]]);s.getRange('A2').format.font={name:'Arial',size:15,bold:true,color:'#222D42'};s.getRange(`A2:${last}2`).format.rowHeight=30;}
function header(s,row,labels){put(s,`A${row}`, [labels]);s.getRangeByIndexes(row-1,0,1,labels.length).format={fill:'#29364D',font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},wrapText:true,rowHeight:42};}
for(const [n,s] of Object.entries(sheets)){s.showGridLines=false;s.getRange('A1:Q600').format.font={name:'Arial',size:10,color:'#243047'};s.getRange('A1:Q600').format.columnWidth=17;s.getRange('A1:Q600').format.rowHeight=21;}
const raw1=sheets['Лист1'],raw2=sheets['Лист2'],data=sheets['Данные'];
header(raw1,1,d.source_headers[0].slice(0,6));put(raw1,'A2',d.rows.map(r=>r.slice(0,6)));raw1.getRange('A2:A505').setNumberFormat('yyyy-mm-dd');raw1.getRange('B1:B505').format.columnWidth=29;
header(raw2,1,[...d.source_headers[1],'Ключ']);
const serial=t=>Date.parse(t+'Z')/86400000+25569;
put(raw2,'A2',d.source2.map(r=>[serial(r[0]),...r.slice(1)]));raw2.getRange('A2:A505').setNumberFormat('yyyy-mm-dd');raw2.getRange('B1:B505').format.columnWidth=29;
f(raw2,'F2:F505',d.source2.map((_,i)=>[`=A${i+2}&"|"&B${i+2}`]));raw2.getRange('F1:F505').format.columnWidth=40;
put(raw1,'H2',[['Источник: Тестирование_корпоративная_аналитика.xlsx, Лист1. Порядок отсортирован по дате и территории.']]);
put(raw2,'H2',[['Источник: Тестирование_корпоративная_аналитика.xlsx, Лист2. Исходный порядок сохранён.']]);
const heads=['Дата','Территория','Товарооборот шт','Товарооборот руб','Себестоимость руб','Потери руб','Склады за день','Заказы за день','Клиенты за день','Понедельник ISO','Год ISO','Неделя ISO','Ключ','Совпадений ключа'];
header(data,1,heads);
for(let col=0;col<6;col++){const letter=String.fromCharCode(65+col);f(data,`${letter}2:${letter}505`,d.rows.map((_,i)=>[`='Лист1'!${letter}${i+2}`]));}
for(let col=6;col<9;col++){const letter=String.fromCharCode(65+col),src=String.fromCharCode(67+col-6);f(data,`${letter}2:${letter}505`,d.rows.map((_,i)=>[`=IF(N${i+2}=1,SUMIFS('Лист2'!$${src}$2:$${src}$505,'Лист2'!$A$2:$A$505,A${i+2},'Лист2'!$B$2:$B$505,B${i+2}),NA())`]));}
f(data,'J2:N505',d.rows.map((_,i)=>{const r=i+2;return [`=A${r}-WEEKDAY(A${r},2)+1`,`=YEAR(J${r}+3)`,`=INT((J${r}-DATE(K${r},1,4)+WEEKDAY(DATE(K${r},1,4),2)-1)/7)+1`,`=A${r}&"|"&B${r}`,`=COUNTIFS('Лист2'!$F$2:$F$505,M${r})`];}));
data.getRange('A2:A505').setNumberFormat('yyyy-mm-dd');data.getRange('J2:J505').setNumberFormat('yyyy-mm-dd');data.getRange('B1:B505').format.columnWidth=29;data.getRange('M1:M505').format.columnWidth=39;
data.tables.add('A1:N505',true,'JoinedData');data.freezePanes.freezeRows(1);
raw1.freezePanes.freezeRows(1);raw2.freezePanes.freezeRows(1);
raw1.getRange('D2:F505').setNumberFormat('#,##0.00');data.getRange('D2:F505').setNumberFormat('#,##0.00');
const sum=sheets['Итоги'];title(sum,'05 — результаты анализа','I');
put(sum,'A4',[['Последняя полная неделя'],['Начало недели'],['Конец недели'],['Оборот компании руб'],['Доходность после потерь']]);sum.getRange('A4:A8').format.columnWidth=31;
f(sum,'B5:B8',[["=MAX('Данные'!A2:A505)-WEEKDAY(MAX('Данные'!A2:A505),2)-6"],['=B5+6'],["=SUMIFS('Данные'!D2:D505,'Данные'!J2:J505,B5)"],["=(B7-SUMIFS('Данные'!E2:E505,'Данные'!J2:J505,B5)-SUMIFS('Данные'!F2:F505,'Данные'!J2:J505,B5))/B7"]]);
sum.getRange('B5:B6').setNumberFormat('yyyy-mm-dd');sum.getRange('B7').setNumberFormat('#,##0.00');sum.getRange('B8').setNumberFormat('0.00%');sum.getRange('B4:B34').format.columnWidth=30;
sum.mergeCells('D4:I5');put(sum,'D4',[['Доходность = (оборот − себестоимость − потери) / оборот. Это доходность после товарных потерь, без операционных затрат.']]);sum.getRange('D4:I5').format.wrapText=true;
sum.mergeCells('D7:I8');put(sum,'D7',[['Склады — среднее за 7 календарных дней. Пропуски территорий не приравниваются к нулевым продажам. Сумма клиентов за дни не является уникальными клиентами недели.']]);sum.getRange('D7:I8').format.wrapText=true;
header(sum,11,['Территория','Оборот руб','Доля оборота','Складо дни','Склады в среднем','Оборот на склад руб','Наценка','Доходность','Ранг доли','Ранг на склад']);
sum.getRange('C1:J35').format.columnWidth=19;sum.getRange('F1:F35').format.columnWidth=24;
for(let i=0;i<d.territories.length;i++){
 const r=12+i;put(sum,`A${r}`,[[d.territories[i]]]);
 f(sum,`B${r}:J${r}`,[[`=SUMIFS('Данные'!$D$2:$D$505,'Данные'!$J$2:$J$505,$B$5,'Данные'!$B$2:$B$505,A${r})`,`=B${r}/$B$7`,`=SUMIFS('Данные'!$G$2:$G$505,'Данные'!$J$2:$J$505,$B$5,'Данные'!$B$2:$B$505,A${r})`,`=D${r}/7`,`=IF(E${r}=0,NA(),B${r}/E${r})`,`=IF(SUMIFS('Данные'!$E$2:$E$505,'Данные'!$J$2:$J$505,$B$5,'Данные'!$B$2:$B$505,A${r})=0,NA(),B${r}/SUMIFS('Данные'!$E$2:$E$505,'Данные'!$J$2:$J$505,$B$5,'Данные'!$B$2:$B$505,A${r})-1)`,`=IF(B${r}=0,NA(),(B${r}-SUMIFS('Данные'!$E$2:$E$505,'Данные'!$J$2:$J$505,$B$5,'Данные'!$B$2:$B$505,A${r})-SUMIFS('Данные'!$F$2:$F$505,'Данные'!$J$2:$J$505,$B$5,'Данные'!$B$2:$B$505,A${r}))/B${r})`,`=RANK(C${r},$C$12:$C$29,0)+COUNTIFS($C$12:C${r},C${r})-1`,`=RANK(F${r},$F$12:$F$29,0)+COUNTIFS($F$12:F${r},F${r})-1`]]);
}
sum.getRange('B12:B29').setNumberFormat('#,##0.00');sum.getRange('C12:C29').setNumberFormat('0.00%');sum.getRange('E12:E29').setNumberFormat('0.00');sum.getRange('F12:F29').setNumberFormat('#,##0.00');sum.getRange('G12:H29').setNumberFormat('0.00%');
header(sum,33,['Топ 3 по доле','Территория','Доля']);header(sum,40,['Топ 3 на склад','Территория','Оборот на склад руб']);
for(let i=0;i<3;i++)for(const [start,rankcol,valcol] of [[34,'I','C'],[41,'J','F']]){const r=start+i;put(sum,`A${r}`,[[i+1]]);f(sum,`B${r}:C${r}`,[[`=INDEX($A$12:$A$29,MATCH(A${r},$${rankcol}$12:$${rankcol}$29,0))`,`=INDEX($${valcol}$12:$${valcol}$29,MATCH(A${r},$${rankcol}$12:$${rankcol}$29,0))`]]);}
sum.getRange('C34:C36').setNumberFormat('0.00%');sum.getRange('C41:C43').setNumberFormat('#,##0.00');sum.getRange('B33:B43').format.columnWidth=30;
sum.getRange('I12:J29').conditionalFormats.add('cellIs',{operator:'lessThanOrEqual',formula:3,format:{fill:'#FCE1EB',font:{bold:true}}});
const detail=sheets['Недели и территории'];title(detail,'Недельные показатели по территориям','M');
header(detail,4,['Понедельник ISO','Территория','Дней с данными','Оборот руб','Себестоимость руб','Потери руб','Складо дни','Среднее складов','Наценка','Доходность','Оборот на склад руб','Заказы','Клиенто дни']);
let rr=5;
for(const week of d.weeks)for(const t of d.territories){const r=rr++;put(detail,`A${r}:B${r}`,[[week,t]]);const crit=`'Данные'!$J$2:$J$505,A${r},'Данные'!$B$2:$B$505,B${r}`;f(detail,`C${r}:M${r}`,[[`=COUNTIFS(${crit})`,...['D','E','F','G'].map(c=>`=SUMIFS('Данные'!$${c}$2:$${c}$505,${crit})`),`=IF(C${r}=0,"н.д.",G${r}/C${r})`,`=IF(E${r}=0,"н.д.",(D${r}-E${r})/E${r})`,`=IF(D${r}=0,"н.д.",(D${r}-E${r}-F${r})/D${r})`,`=IF(G${r}=0,"н.д.",D${r}/H${r})`,...['H','I'].map(c=>`=SUMIFS('Данные'!$${c}$2:$${c}$505,${crit})`)]]);}
detail.getRange(`A5:A${rr-1}`).setNumberFormat('yyyy-mm-dd');detail.getRange(`D5:H${rr-1}`).setNumberFormat('#,##0.00');detail.getRange(`I5:J${rr-1}`).setNumberFormat('0.00%');detail.getRange(`K5:K${rr-1}`).setNumberFormat('#,##0.00');detail.getRange(`B1:B${rr}`).format.columnWidth=30;detail.freezePanes.freezeRows(4);
put(detail,'A115',[['Неполные недели и территории: среднее складов рассчитано по дням наблюдений; рейтинг полной недели на Итогах использует 7 дней.']]);
const dyn=sheets['Динамика'];title(dyn,'Динамика по неделям ISO','I');
header(dyn,4,['Неделя ISO','Первый день','Дней в данных','Товарооборот руб','Себестоимость руб','Потери руб','Наценка','Доходность','Полная неделя']);
for(let i=0;i<d.weeks.length;i++){const r=i+5;put(dyn,`B${r}`,[[d.weeks[i]]]);const cond=`'Данные'!$J$2:$J$505,B${r}`;f(dyn,`A${r}`,[[`=YEAR(B${r}+3)&"-W"&TEXT(INT((B${r}-DATE(YEAR(B${r}+3),1,4)+WEEKDAY(DATE(YEAR(B${r}+3),1,4),2)-1)/7)+1,"00")`]]);f(dyn,`C${r}:I${r}`,[[`=MIN(7,MAX('Данные'!$A$2:$A$505)-B${r}+1)-MAX(0,MIN('Данные'!$A$2:$A$505)-B${r})`,...['D','E','F'].map(c=>`=SUMIFS('Данные'!$${c}$2:$${c}$505,${cond})`),`=(D${r}-E${r})/E${r}`,`=(D${r}-E${r}-F${r})/D${r}`,`=IF(C${r}=7,"Да","Нет")`]]);}
dyn.getRange('B5:B10').setNumberFormat('yyyy-mm-dd');dyn.getRange('D5:F10').setNumberFormat('#,##0.00');dyn.getRange('G5:H10').setNumberFormat('0.00%');
for(const [col,label,fmt,start,end,color] of [['D','Товарооборот по неделям руб','0.0,," млн"','A13','I28','#EC4A77'],['H','Доходность после потерь по неделям','0.0%','A30','I45','#376EA0']]){
const chart=dyn.charts.add('line',[dyn.getRange('A4:A10'),dyn.getRange(`${col}4:${col}10`)]);chart.title=label;chart.setPosition(start,end);chart.hasLegend=false;chart.titleTextStyle.fontSize=14;chart.titleTextStyle.typeface='Arial';chart.xAxis={axisType:'textAxis',textStyle:{typeface:'Arial',fontSize:11}};chart.yAxis={numberFormatCode:fmt,numberFormatSourceLinked:false,textStyle:{typeface:'Arial',fontSize:11}};chart.series.items[0].line={fill:color,width:2,style:'solid'};}
put(dyn,'A47',[['W18 и W23 неполные. Изменение их сумм нельзя трактовать как изменение недельного спроса.']]);
const mon=sheets['Месячные показатели'];title(mon,'Месячные показатели исходных графиков','I');
header(mon,4,['Месяц',...d.charts.map(c=>c.title)]);
put(mon,'A5',d.charts[0].months.map((m,i)=>[m,...d.charts.map(c=>c.values[i])]));mon.getRange('B5:H17').setNumberFormat('#,##0.00');mon.getRange('I5:I17').setNumberFormat('0.000%');mon.getRange('A4:I4').format.rowHeight=65;mon.getRange('A1:I25').format.columnWidth=22;
put(mon,'A20',[['Источник: кэш 8 диаграмм листа Задание. Это отдельный месячный ряд май 2019 — май 2020.']]);put(mon,'A22',[['У запаса конфликт единиц: заголовок говорит тыс.руб., ряд — млн руб. Использовать относительные изменения.']]);
header(mon,25,['Показатель','Апрель 2020','Май 2020','Изменение']);
for(let i=0;i<8;i++){let r=26+i;let col=String.fromCharCode(66+i);put(mon,`A${r}`,[[d.charts[i].series]]);f(mon,`B${r}:D${r}`,[[`=${col}16`,`=${col}17`,i===7?`=C${r}-B${r}`:`=C${r}/B${r}-1`]]);}
mon.getRange('A25:A33').format.columnWidth=48;mon.getRange('D26:D32').setNumberFormat('0.00%');f(mon,'D33',[['=(C33-B33)*100']]);mon.getRange('D33').setNumberFormat('0.000" п.п."');mon.getRange('B26:C32').setNumberFormat('#,##0.00');mon.getRange('B33:C33').setNumberFormat('0.000%');
const audit=sheets['Проверки'];title(audit,'Проверки объединения и расчётов','D');header(audit,4,['Проверка','Факт','Ожидание','Разница']);
const checks=[['Строк в данных',"=COUNTA('Данные'!A2:A505)",504],['Ключи без единственного совпадения',"=504-COUNTIFS('Данные'!N2:N505,1)",0],['Оборот исходный',"=SUM('Лист1'!D2:D505)",d.rows.reduce((s,r)=>s+r[3],0)],['Оборот объединённый',"=SUM('Данные'!D2:D505)",d.rows.reduce((s,r)=>s+r[3],0)],['Склады дни после объединения',"=SUM('Данные'!G2:G505)",d.rows.reduce((s,r)=>s+r[6],0)],['Заказы после объединения',"=SUM('Данные'!H2:H505)",d.rows.reduce((s,r)=>s+r[7],0)],['Клиенто дни после объединения',"=SUM('Данные'!I2:I505)",d.rows.reduce((s,r)=>s+r[8],0)],['Сумма недельного оборота',"=SUM('Динамика'!D5:D10)",d.rows.reduce((s,r)=>s+r[3],0)],['Сумма долей последней недели',"=SUM('Итоги'!C12:C29)",1]];
for(let i=0;i<checks.length;i++){const r=i+5;put(audit,`A${r}`,[[checks[i][0]]]);f(audit,`B${r}`,[[checks[i][1]]]);put(audit,`C${r}`,[[checks[i][2]]]);f(audit,`D${r}`,[[`=B${r}-C${r}`]]);}
audit.getRange('A1:A16').format.columnWidth=43;audit.getRange('B1:C16').format.columnWidth=28;audit.getRange('D1:D16').format.columnWidth=20;audit.getRange('B5:C13').setNumberFormat('#,##0.00');audit.getRange('D5:D13').setNumberFormat('0.000000');audit.getRange('D5:D13').conditionalFormats.add('cellIs',{operator:'notEqual',formula:0,format:{fill:'#FFE0E0',font:{color:'#9F1239'}}});
title(sheets['Сводная'],'Сводная таблица по неделям и территориям','J');
sheets['Сводная'].getRange('A1:A105').format.columnWidth=19;sheets['Сводная'].getRange('B1:B105').format.columnWidth=30;sheets['Сводная'].getRange('C1:H105').format.columnWidth=22;
const tests=[];
const originalWarehouse=raw2.getRange('C2').values[0][0];
raw2.getRange('C2').values=[[originalWarehouse+1]];
const target=d.rows.findIndex(r=>r[0]===serial(d.source2[0][0])&&r[1]===d.source2[0][1])+2;
if(data.getRange(`G${target}`).values[0][0]!==originalWarehouse+1)throw new Error('Source warehouse edit did not propagate');
raw2.getRange('C2').values=[[originalWarehouse]];tests.push('Source warehouse change propagated to joined data and restored');
const idx=d.rows.findIndex(r=>r[9]===d.last_full&&r[1]==='Волгоград'),originalSales=d.rows[idx][3];
raw1.getRange(`D${idx+2}`).values=[[originalSales+1e10]];
if(sum.getRange('B34').values[0][0]!=='Волгоград')throw new Error('Ranking did not react to changed source revenue');
raw1.getRange(`D${idx+2}`).values=[[originalSales]];tests.push('Large source revenue edit changed top territory and restored original ranking');
await fs.writeFile(path.join(root,'qa/behavior.json'),JSON.stringify(tests));
wb.recalculate();
console.log((await wb.inspect({kind:'region',sheetId:'Итоги',range:'A34:C43',maxChars:1800,tableMaxRows:10,tableMaxCols:3})).ndjson);
console.log((await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!',options:{useRegex:true,maxResults:10},maxChars:1500})).ndjson);
for(const [name,range] of [['Итоги','A2:J29'],['Динамика','A2:I45'],['Месячные показатели','A25:D33'],['Данные','A1:F9'],['Лист1','A1:F9'],['Лист2','A1:F9'],['Недели и территории','A4:M12'],['Проверки','A4:D13']]){
 const blob=await wb.render({sheetName:name,range,scale:1.5,format:'png'});await fs.writeFile(path.join(root,'qa',`${name}.png`),new Uint8Array(await blob.arrayBuffer()));}
const out=await SpreadsheetFile.exportXlsx(wb);await out.save(path.join(root,'output','05_решение.xlsx'));
await fs.writeFile(path.join(root,'qa','artifact-values.json'),JSON.stringify({summary:sum.getRange('A12:J29').values,checks:audit.getRange('A5:D13').values,dynamics:dyn.getRange('A5:I10').values}));
console.log('Workbook exported');

